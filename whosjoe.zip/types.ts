
export interface Game {
  id: string;
  title: string;
  description: string;
  url: string;
  thumbnail: string;
  category: 'Strategy' | 'Action' | 'Idle' | 'Driving';
}

export type StealthPreset = 'Default' | 'Google' | 'Canvas' | 'Classroom' | 'Drive';

export interface StealthConfig {
  title: string;
  icon: string;
}
