
export const GAMES_DATA = [
  {
    id: 'cookie-clicker',
    title: 'Cookie Clicker',
    description: 'The original idle game where you bake billions of cookies.',
    url: 'https://orteil.dashnet.org/cookieclicker/',
    thumbnail: 'https://picsum.photos/seed/cookie/400/225',
    category: 'Idle'
  },
  {
    id: '1v1-lol',
    title: '1v1.lol',
    description: 'Competitive third-person shooter and building simulator.',
    url: 'https://1v1.lol/',
    thumbnail: 'https://picsum.photos/seed/1v1/400/225',
    category: 'Action'
  },
  {
    id: 'polytrack',
    title: 'Polytrack',
    description: 'Fast-paced racing game with custom track creation.',
    url: 'https://polytrack.io/',
    thumbnail: 'https://picsum.photos/seed/polytrack/400/225',
    category: 'Driving'
  },
  {
    id: 'adventure-capitalist',
    title: 'AdVenture Capitalist',
    description: "The world's greatest capitalism simulator.",
    url: 'https://www.kongregate.com/games/hyperhippo/adventure-capitalist',
    thumbnail: 'https://picsum.photos/seed/capitalist/400/225',
    category: 'Idle'
  },
  {
    id: 'slope',
    title: 'Slope',
    description: 'Navigate a ball down a treacherous neon slope.',
    url: 'https://krunker.io/',
    thumbnail: 'https://picsum.photos/seed/slope/400/225',
    category: 'Action'
  }
];

export const STEALTH_PRESETS = {
  Default: {
    title: 'Nova Games | Hub',
    icon: 'https://www.google.com/favicon.ico'
  },
  Google: {
    title: 'Google',
    icon: 'https://www.google.com/favicon.ico'
  },
  Canvas: {
    title: 'Dashboard',
    icon: 'https://canvas.instructure.com/favicon.ico'
  },
  Classroom: {
    title: 'Classes',
    icon: 'https://www.gstatic.com/classroom/favicon.png'
  },
  Drive: {
    title: 'My Drive - Google Drive',
    icon: 'https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png'
  }
};
