
import React from 'react';
import { StealthPreset } from '../types';
import { STEALTH_PRESETS } from '../constants';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPreset: StealthPreset;
  onPresetChange: (preset: StealthPreset) => void;
  onLaunchAboutBlank: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, 
  onClose, 
  currentPreset, 
  onPresetChange,
  onLaunchAboutBlank
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Stealth Settings
          </h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
              Tab Cloaking
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(STEALTH_PRESETS) as StealthPreset[]).map((preset) => (
                <button
                  key={preset}
                  onClick={() => onPresetChange(preset)}
                  className={`flex items-center gap-2 p-3 rounded-xl border text-sm transition-all ${
                    currentPreset === preset 
                      ? 'bg-indigo-600/10 border-indigo-500 text-white' 
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
                  }`}
                >
                  <img src={STEALTH_PRESETS[preset].icon} alt="" className="w-5 h-5 rounded-sm" />
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <label className="block text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
              Advanced Masking
            </label>
            <button
              onClick={onLaunchAboutBlank}
              className="w-full flex items-center justify-center gap-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20 active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              Launch in About:Blank
            </button>
            <p className="text-[10px] text-slate-500 mt-3 text-center leading-relaxed">
              This opens the current site in a new "About:Blank" tab, which helps prevent history tracking and bypasses most extension detections.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
