
import React, { useState } from 'react';
import { Game } from '../types';

interface GameViewProps {
  game: Game;
  onBack: () => void;
}

export const GameView: React.FC<GameViewProps> = ({ game, onBack }) => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <div className="fixed inset-0 z-40 bg-slate-950 flex flex-col">
      <div className="bg-slate-900 px-4 py-2 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm font-medium"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Exit Game
          </button>
          <div className="h-4 w-px bg-slate-800"></div>
          <h2 className="text-white font-bold">{game.title}</h2>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => window.location.reload()}
            className="p-1.5 hover:bg-slate-800 rounded transition-colors text-slate-400 hover:text-white"
            title="Reload Game"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
          <button 
            onClick={() => {
              const el = document.getElementById('game-iframe');
              if (el?.requestFullscreen) el.requestFullscreen();
            }}
            className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded transition-colors"
          >
            Fullscreen
          </button>
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950 z-10">
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-slate-400 font-medium animate-pulse">Loading {game.title}...</p>
            </div>
          </div>
        )}
        <iframe
          id="game-iframe"
          src={game.url}
          className="w-full h-full border-none"
          allow="fullscreen; autoplay; cursor-lock"
          onLoad={() => setIsLoading(false)}
        ></iframe>
      </div>
    </div>
  );
};
