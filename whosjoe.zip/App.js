
import React, { useState, useEffect, useCallback } from 'react';
import { GAMES_DATA, STEALTH_PRESETS } from './constants';
import { Navbar } from './components/Navbar';
import { GameCard } from './components/GameCard';
import { SettingsModal } from './components/SettingsModal';
import { GameView } from './components/GameView';

const App = () => {
  const [selectedGame, setSelectedGame] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [currentPreset, setCurrentPreset] = useState('Default');

  // Apply stealth settings
  useEffect(() => {
    const config = STEALTH_PRESETS[currentPreset];
    document.title = config.title;
    const favicon = document.getElementById('favicon');
    if (favicon) {
      favicon.href = config.icon;
    }
  }, [currentPreset]);

  const filteredGames = GAMES_DATA.filter(game => 
    game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    game.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleLaunchAboutBlank = useCallback(() => {
    const win = window.open('about:blank', '_blank');
    if (!win) {
      alert('Please allow popups for this site to use About:Blank masking.');
      return;
    }

    const iframe = win.document.createElement('iframe');
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.style.overflow = 'hidden';

    const style = iframe.style;
    style.position = 'fixed';
    style.top = '0';
    style.left = '0';
    style.bottom = '0';
    style.right = '0';
    style.width = '100%';
    style.height = '100%';
    style.border = 'none';
    style.margin = '0';
    style.padding = '0';
    style.overflow = 'hidden';
    style.zIndex = '999999';

    iframe.src = window.location.href;
    win.document.body.appendChild(iframe);
  }, []);

  const handleGoHome = () => {
    setSelectedGame(null);
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar 
        onOpenSettings={() => setIsSettingsOpen(true)} 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onGoHome={handleGoHome}
      />

      <main className="flex-1 p-6 md:p-10">
        <header className="mb-10">
          <h2 className="text-3xl font-extrabold text-white mb-2">Featured Games</h2>
          <p className="text-slate-400">Hand-picked high performance games for your enjoyment.</p>
        </header>

        {filteredGames.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
            {filteredGames.map((game) => (
              <GameCard 
                key={game.id} 
                game={game} 
                onSelect={setSelectedGame} 
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-xl font-medium">No games found matching your search.</p>
            <button 
              onClick={() => setSearchQuery('')}
              className="mt-4 text-indigo-500 hover:underline"
            >
              Clear search filter
            </button>
          </div>
        )}
      </main>

      <footer className="py-8 px-6 border-t border-slate-800 text-center text-slate-500 text-sm">
        <div className="flex items-center justify-center gap-6 mb-4">
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <a href="#" className="hover:text-white transition-colors">Discord</a>
          <a href="#" className="hover:text-white transition-colors">Request Game</a>
        </div>
        <p>&copy; 2024 Nova Games Hub. All rights reserved.</p>
      </footer>

      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentPreset={currentPreset}
        onPresetChange={setCurrentPreset}
        onLaunchAboutBlank={handleLaunchAboutBlank}
      />

      {selectedGame && (
        <GameView 
          game={selectedGame} 
          onBack={() => setSelectedGame(null)} 
        />
      )}
    </div>
  );
};

export default App;
